package lab7.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/Login")
public class Login extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public Login() {
        super();
    }
    

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// set content to text/html
		response.setContentType("text/html");
		// writer for the servlet
		PrintWriter output = response.getWriter();

		output.println("<html><head><title>Login</title></head><body>");
		output.println("<form name='loginForm' action=\"Login\" method=\"post\">");
		// field that contains username
		output.println("<div name='usernameDiv'>");
		output.println("Username: <input type=\"text\" name=\"usernameInput\">");
		output.println("</div><br>");
		// field that contains password
		output.println("<div name='passwordDiv'>");
		output.println("Password: <input type=\"password\" name=\"passwordInput\">");
		output.println("</div><br>");
		// login button
		output.println("<button type='submit'>Login</button></form>");
		output.println("</body></html>");
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// get and save the username and password from the form
		String username = request.getParameter("usernameInput");
		String password = request.getParameter("passwordInput");
		
		// check if the input is a valid login
		if(username.equals("cysun") && password.equals("abcd")) {
			// if so then create a new cookie with username and add cookie
        	String name = request.getParameter("username");
        	Cookie cookie = new Cookie ("name",name);
        	response.addCookie(cookie);
        	
        	// redirect user to 'Members' page
			response.sendRedirect("Members");
		}
		else {
			// if not valid login then redirect to form
			response.sendRedirect("Login");
		}
		
	}

}
