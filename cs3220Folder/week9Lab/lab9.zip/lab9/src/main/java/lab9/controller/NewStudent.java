package lab9.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import lab9.model.NewGroupEntry;
import lab9.model.NewStudentEntry;


@WebServlet(urlPatterns="/NewStudent", loadOnStartup=1)
public class NewStudent extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public NewStudent() {
        super();
    }
    
    public void init(ServletConfig config) throws ServletException {
    	super.init(config);
    	// create a list to track the groups available
    	List<NewGroupEntry> groupEntries = new ArrayList<NewGroupEntry>();
    	
    	// create a list to track the groups available
    	List<NewStudentEntry> studentEntries = new ArrayList<NewStudentEntry>();
    	
    	// set the attribute of groupEntries
    	getServletContext().setAttribute("groupEntries", groupEntries);
    	
    	// set the attribute of studentEntries
    	getServletContext().setAttribute("studentEntries", studentEntries);
    }
    
    private NewGroupEntry getGroup(int id) {
    	// get all groups that are available
    	ArrayList<NewGroupEntry> groupEntries = (ArrayList<NewGroupEntry>) getServletContext().getAttribute("groupEntries");
    	// loop through all groups that are available
    	for(NewGroupEntry currentGroup:groupEntries) {
    		// if the group id's match
    		if(currentGroup.getId() == id) {
    			// return the current group that has matching id
    			return currentGroup;
    		}
    	}
    	return null;
    		
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {	
		// ArrayList holding Groups available
		List<NewGroupEntry> groupEntries = (ArrayList<NewGroupEntry>) getServletContext().getAttribute("groupEntries");
		
		// redirec the user to the NewStudentPage jsp
		request.getRequestDispatcher("/WEB-INF/NewStudentPage.jsp").forward(request, response);

		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// create a new student with correct group
		String name = request.getParameter("nameInput");
		int birthYear = Integer.parseInt(request.getParameter("birthYearInput"));
		String parentName = request.getParameter("parentNameInput");
		String parentEmail = request.getParameter("parentEmailInput");
		// check to make determine if student has group or not
		NewGroupEntry group=null;
		if(Integer.parseInt(request.getParameter("groupDropdown")) == 0) {
			group= new NewGroupEntry("No Group");
		}
		else {
			group = getGroup(Integer.parseInt(request.getParameter("groupDropdown")));
		}
		group.addStudent();
		NewStudentEntry entry = new NewStudentEntry(name, birthYear, parentName, parentEmail, group);
		
		// get and save the groupEntries attribute
		ArrayList<NewStudentEntry> studentEntries = (ArrayList<NewStudentEntry>) getServletContext().getAttribute("studentEntries");
		// add the entry to groupEntries
		studentEntries.add(entry);
		
		// redirect user to GroupListingPage
		response.sendRedirect("StudentListing");
		
	}

}
