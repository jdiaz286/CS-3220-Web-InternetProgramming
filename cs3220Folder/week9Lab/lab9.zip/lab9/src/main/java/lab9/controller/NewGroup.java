package lab9.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import lab9.model.NewGroupEntry;
import lab9.model.NewStudentEntry;


@WebServlet(urlPatterns="/NewGroup", loadOnStartup=1)
public class NewGroup extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public NewGroup() {
        super();
    }
    
    public void init(ServletConfig config) throws ServletException {
    	super.init(config);
    	// create a list to track the groups available
    	List<NewGroupEntry> groupEntries = new ArrayList<NewGroupEntry>();
    	
    	// create a list to track the groups available
    	List<NewStudentEntry> studentEntries = new ArrayList<NewStudentEntry>();
    	
    	// set the attribute of groupEntries
    	getServletContext().setAttribute("groupEntries", groupEntries);
    	
    	// set the attribute of studentEntries
    	getServletContext().setAttribute("studentEntries", studentEntries);
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// redirect the user to the NewGroupPage jsp
		request.getRequestDispatcher("/WEB-INF/NewGroupPage.jsp").forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// get the name that was used in the input
		String groupName = request.getParameter("groupNameInput");
		// create a NewGroupEntry with input name
		NewGroupEntry entry = new NewGroupEntry(groupName);
		
		// get and save the groupEntries attribute
		ArrayList<NewGroupEntry> groupEntries = (ArrayList<NewGroupEntry>) getServletContext().getAttribute("groupEntries");
		
		// add the entry to groupEntries
		groupEntries.add(entry);
		
		// redirect user to GroupListingPage
		response.sendRedirect("GroupListing");
	}

}
