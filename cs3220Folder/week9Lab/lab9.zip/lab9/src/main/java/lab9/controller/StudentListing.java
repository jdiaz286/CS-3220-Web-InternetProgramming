package lab9.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Calendar;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import lab9.model.NewGroupEntry;
import lab9.model.NewStudentEntry;


@WebServlet("/StudentListing")
public class StudentListing extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private static int currentYear = Calendar.getInstance().get(Calendar.YEAR);
       
    public StudentListing() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// ArrayList holding Groups available
		ArrayList<NewGroupEntry> groupEntries = (ArrayList<NewGroupEntry>) getServletContext().getAttribute("groupEntries");
		
		//ArrayList holding students available
		ArrayList<NewStudentEntry> studentEntries = (ArrayList<NewStudentEntry>) getServletContext().getAttribute("studentEntries");
		
		// if there are no students then just show the "New Student" link
		if(studentEntries.isEmpty()) {
			// redirect user to the blank jsp page
			request.getRequestDispatcher("/WEB-INF/BlankStudentListingPage.jsp").forward(request, response);
		}
		// if there are students then display them
		else {
			// send the currentYear to the jsp
			request.setAttribute("currentYear", currentYear);
			// redirect the user to the student listing page
			request.getRequestDispatcher("/WEB-INF/StudentListingPage.jsp").forward(request, response);
			
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}