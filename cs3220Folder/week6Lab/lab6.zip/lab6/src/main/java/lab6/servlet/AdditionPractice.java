package lab6.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Random;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/AdditionPractice")
public class AdditionPractice extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public AdditionPractice() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter output = response.getWriter();
		// create two random ints and get the sum
		Random random = new Random();
		int firstRandomInt = random.nextInt(9)+1;
		int secondRandomInt = random.nextInt(9)+1;
		
		output.println("<html><head><title>Addition Practice</title></head><body>");
		output.println("<form name='equationForm' action=\"AdditionPractice\" method=\"post\">");
		// span that holds the equation 
		output.println("<span name='equationLabel'>"+firstRandomInt+" + "+secondRandomInt+" = "+"</span>");
		// field that contains the users guess
		output.println("<input type=\"text\" name=\"userGuess\">");
		// hidden form fields that are passed to doPost()
		output.println("<input type=\"hidden\" name=\"firstRandomInt\" value="+firstRandomInt+">");
		output.println("<input type=\"hidden\" name=\"secondRandomInt\" value="+secondRandomInt+">");
		// button on the page
		output.println("<button type='submit'>Submit</button></form>");
		output.println("</body></html>");
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// get and save the integers that were used in doGet()
		int firstRandomInt = Integer.parseInt(request.getParameter("firstRandomInt"));
		int secondRandomInt = Integer.parseInt(request.getParameter("secondRandomInt"));
		
		// get and save the user guess from the previous page
		int userGuess = Integer.parseInt(request.getParameter("userGuess"));
		//request.getParameter("equationForm")
				
		// calculate the correct sum
		int sum = firstRandomInt + secondRandomInt;
		
		// writer for the page
		PrintWriter output = response.getWriter();
		
		output.println("<html><head><title>Addition Practice</title></head><body>");
		
		// display the complete equation and answer
		output.println("<p>"+firstRandomInt+" + "+secondRandomInt+" = "+sum+"</p>");
		
		// determine if the user's guess is correct and display if so
		if(userGuess==sum) {
			output.println("<p> Your answer "+userGuess+" is correct! "+"</p>");
		}
		else {	
			output.println("<p> Your answer "+userGuess+" is incorrect. "+"</p>");
		}
		
		output.println("<a href='AdditionPractice'>Try Again</a>");
		output.println("</body></html>");
		
	}

}
