package lab12.controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import lab12.model.Department;
import lab12.model.Faculty;

@WebServlet(urlPatterns = "/DisplayFaculty", loadOnStartup = 1)
public class DisplayFaculty extends HttpServlet {

    private static final long serialVersionUID = 1L;

    public DisplayFaculty(){
        super();
    }

    protected void doGet( HttpServletRequest request,HttpServletResponse response ) throws ServletException, IOException{
    	// get data from database
    	Connection c = null;
        try {
        	// info used for the database connection
        	String url = "jdbc:mysql://cs3.calstatela.edu/cs3220stu10";
        	String username = "cs3220stu10";
        	String password = "5OEoA5hQP8Cc";
        	
        	// connect to database and then get all values from department table
        	c = DriverManager.getConnection(url, username, password);
        	Statement stmnt1 = c.createStatement();
        	Statement stmnt2 = c.createStatement();
        	
        	// execute first statement to get all values from department table
        	ResultSet rs = stmnt1.executeQuery("select * from department");
        	
        	// create a list of departments
        	List<Department> departments = new ArrayList<Department>();
        	
        	// while there are still entries, create new department and add to arrayList
        	while(rs.next()) {
        		Department entry = new Department();
        		entry.setName(rs.getString("name"));
        		//possibly set the faculty here
        		departments.add(entry);
        		
        		// execute second statment and get all faculty with current department name
        		ResultSet facultyResult = stmnt2.executeQuery("select * from faculty where department_name=\""+ rs.getString("name")+"\"");

        		// loop through all results to get the faculty and add them to the arrayList of Department
        		while(facultyResult.next()) {
        			// if the faculty is in the table returned, add their name to the faculty arraylist
        			Faculty newFacultyMember = new Faculty(facultyResult.getString("name"));
        			// make sure to check if the faculty is a chair
        			boolean isChair = facultyResult.getBoolean("is_chair");
        			if(isChair) {
        				newFacultyMember.setChair(true);
        			}
        			entry.getFaculty().add(newFacultyMember);
        		}
        	}
        	// pass the list to view
        	request.setAttribute("departments", departments);
        }
        // catch any problems with connecting to database
        catch( SQLException e) {
        	throw new ServletException(e);
        }
        // if all went well, close off the connection to the mysql database
        finally {
        	try {
        		if(c!=null) c.close();
        	}
        	catch(SQLException e) {
        		throw new ServletException(e);
        	}
        }
        
    	//redirect the user to the jsp page
        request.getRequestDispatcher( "/WEB-INF/lab12/DisplayFaculty.jsp" ).forward( request, response );
    }

}