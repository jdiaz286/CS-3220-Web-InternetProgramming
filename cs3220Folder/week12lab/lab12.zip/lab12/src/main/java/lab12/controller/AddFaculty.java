package lab12.controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import lab12.model.Department;
import lab12.model.Faculty;

@WebServlet("/AddFaculty")
public class AddFaculty extends HttpServlet {

    private static final long serialVersionUID = 1L;

    public AddFaculty(){
        super();
    }

    protected void doGet( HttpServletRequest request, HttpServletResponse response ) throws ServletException, IOException{
    	// get all the departments from the database and add to list and send to jsp file to show in dropdown
    	Connection c = null;
        try {
        	String url = "jdbc:mysql://cs3.calstatela.edu/cs3220stu10";
        	String username = "cs3220stu10";
        	String password = "5OEoA5hQP8Cc";
        	
        	c = DriverManager.getConnection(url, username, password);
        	Statement stmnt = c.createStatement();
        	ResultSet rs = stmnt.executeQuery("select * from department");
        	
        	// create a list of departments
        	List<Department> departments = new ArrayList<Department>();
        	
        	while(rs.next()) {
        		Department entry = new Department();
        		entry.setName(rs.getString("name"));
        		//possibly set the faculty here
        		departments.add(entry);
        	}
        	// pass the list to view
        	request.setAttribute("departments", departments);
        	
        }
        catch( SQLException e) {
        	throw new ServletException(e);
        }
        finally {
        	try {
        		if(c!=null) c.close();
        	}
        	catch(SQLException e) {
        		throw new ServletException(e);
        	}
        }
        
    	// redirect the user to the jsp page
        request.getRequestDispatcher( "/WEB-INF/lab12/AddFaculty.jsp" ).forward( request, response );
    }

    @SuppressWarnings("unchecked")
    protected void doPost( HttpServletRequest request,HttpServletResponse response ) throws ServletException, IOException{
    	// get the department target to add faculty
        String departmentName = request.getParameter( "department" );
        
        // get the name of the newly added faculty member
        String facultyName = request.getParameter("faculty");
        
        // get the boolean value for if the person is a chair
        int isChair = 0;
        if( request.getParameter( "chair" ) != null ){ 
        	isChair= 1;
        }
        
        // faculty to compare in the database
        Faculty faculty = new Faculty(facultyName);
        
        Connection c = null;
        try {
        	String url = "jdbc:mysql://cs3.calstatela.edu/cs3220stu10";
        	String username = "cs3220stu10";
        	String password = "5OEoA5hQP8Cc";
        	
        	c = DriverManager.getConnection(url, username, password);
        	
        	Statement stmnt = c.createStatement();
        	String sql = "insert into faculty (name,is_chair,department_name) values ('"+facultyName+"', '"+isChair+"', '"+departmentName+"')";
        	stmnt.executeUpdate(sql);
        	
        	// For some reason the command below doesn't work when using jdbc, however
        	// when executing the command as a query on mysql it works. This appears to be
        	// some type of bug. What could be done in this situation?
        	/*
        	// executes sql statement so no special characters affect database
        	String sql = "insert into faculty (name, is_chair, department_name) values values (?, ?, ?)";
        	
        	// set the values to be added to the database
        	PreparedStatement pstmnt = c.prepareStatement(sql);
        	pstmnt.setString(1, facultyName);
        	pstmnt.setString(2, Integer.toString(isChair));
        	pstmnt.setString(3, departmentName);
        	
        	// execute the database update
        	pstmnt.executeUpdate();
        	*/
        }
        // catch any problems with connection to sql server
        catch( SQLException e) {
        	throw new ServletException(e);
        }
        // if all went well, be sure to close off the connection
        finally {
        	try {
        		if(c!=null) c.close();
        	}
        	catch(SQLException e) {
        		throw new ServletException(e);
        	}
        }
        
        // redirect the page info to DisplayFaculty servlet
        response.sendRedirect( "DisplayFaculty" );
    }

}